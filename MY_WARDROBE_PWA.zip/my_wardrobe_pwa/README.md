# MY WARDROBE — PWA ilk sürüm

## İçerik
- Fotoğrafla kıyafet ekleme
- Kategorilere göre dijital gardırop
- Dolaptaki parçalardan kural tabanlı kombin önerisi
- Kombin favorileri
- Stil profili
- IndexedDB ile fotoğrafları cihaz tarayıcısında saklama
- PWA manifest + service worker

## Telefona yükleme
PWA'nın kurulabilmesi için site HTTPS üzerinden yayınlanmalıdır (localhost geliştirme için istisnadır).

Kolay yayınlama:
1. Bu ZIP dosyasını aç.
2. İçindeki dosyaları GitHub'da yeni bir repository'ye yükle.
3. Repository Settings → Pages → Deploy from a branch → main / root seç.
4. Yayınlanan HTTPS adresini iPhone Safari'de aç.
5. Paylaş → Ana Ekrana Ekle → Ekle.

Alternatif: Netlify veya Vercel'e klasörü/ZIP'i yükleyerek HTTPS adresi alabilirsin.

## Önemli notlar
- Bu sürümde veriler sunucuya gönderilmez; aynı cihazdaki aynı tarayıcıda tutulur.
- Safari web sitesi verilerini temizlersen kıyafet kayıtların silinebilir.
- Kombin önerileri şu an dolaptaki kategori ve stil etiketlerine göre yerel kurallarla oluşturulur; bulut tabanlı yapay zekâ bağlantısı değildir.
- Veriler cihazlar arasında otomatik senkronize olmaz.
- Fotoğraflar IndexedDB içinde saklanır. Büyük görseller çok yer kaplayabilir.
